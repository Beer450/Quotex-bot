"""
xgboost_validator.py — ENHANCED AI VALIDATION LAYER
"""

import pandas as pd
import numpy as np
import ta
import os
import joblib
import logging
from xgboost import XGBClassifier
from sklearn.model_selection import cross_val_score
from sklearn.preprocessing import StandardScaler

logger = logging.getLogger(__name__)

# Replit-safe absolute paths
BASE_DIR    = os.path.dirname(os.path.abspath(__file__))
MODEL_PATH  = os.path.join(BASE_DIR, 'trained_xgb_model.pkl')
SCALER_PATH = os.path.join(BASE_DIR, 'trained_xgb_scaler.pkl')

def extract_features(df):
    close = df['close'].astype(float)
    high  = df['high'].astype(float)
    low   = df['low'].astype(float)
    open_ = df['open'].astype(float)

    ema9  = ta.trend.EMAIndicator(close, 9).ema_indicator()
    ema21 = ta.trend.EMAIndicator(close, 21).ema_indicator()
    ema50 = ta.trend.EMAIndicator(close, 50).ema_indicator()
    macd  = ta.trend.MACD(close)
    adx   = ta.trend.ADXIndicator(high, low, close, 14)
    rsi   = ta.momentum.RSIIndicator(close, 14).rsi()
    stoch = ta.momentum.StochasticOscillator(high, low, close, 14, 3)
    stochrsi = ta.momentum.StochRSIIndicator(close, 14, 3, 3)
    cci   = ta.trend.CCIIndicator(high, low, close, 20).cci()
    willr = ta.momentum.WilliamsRIndicator(high, low, close, 14).williams_r()
    mom   = ta.momentum.ROCIndicator(close, 10).roc()
    bb    = ta.volatility.BollingerBands(close, 20, 2)
    atr   = ta.volatility.AverageTrueRange(high, low, close, 14).average_true_range()
    kc    = ta.volatility.KeltnerChannel(high, low, close, 20)

    body     = (close - open_).abs()
    body_pct = body / (high - low + 1e-10)
    direction= np.sign(close - open_)
    target   = (close.shift(-1) > close).astype(int)

    feat = pd.DataFrame({
        'ema_diff_9_21':  (ema9 - ema21) / ema21,
        'ema_diff_21_50': (ema21 - ema50) / ema50,
        'price_vs_ema9':  (close - ema9) / ema9,
        'price_vs_ema21': (close - ema21) / ema21,
        'macd_line':      macd.macd(),
        'macd_hist':      macd.macd_diff(),
        'macd_hist_chg':  macd.macd_diff().diff(),
        'adx':            adx.adx(),
        'di_diff':        adx.adx_pos() - adx.adx_neg(),
        'rsi':            rsi,
        'rsi_chg':        rsi.diff(),
        'stoch_k':        stoch.stoch(),
        'stoch_d':        stoch.stoch_signal(),
        'stochrsi_k':     stochrsi.stochrsi_k(),
        'cci':            cci,
        'williams_r':     willr,
        'roc':            mom,
        'bb_pct':         bb.bollinger_pband(),
        'bb_width':       (bb.bollinger_hband() - bb.bollinger_lband()) / bb.bollinger_mavg(),
        'atr_pct':        atr / close,
        'kc_pct':         kc.keltner_channel_pband(),
        'body_pct':       body_pct,
        'direction':      direction,
        'hl_range_pct':   (high - low) / close,
        'target':         target,
    }).dropna()

    return feat


def train_model(df):
    features = extract_features(df)
    if len(features) < 100:
        logger.warning("[XGB] Not enough data to train.")
        return None

    X = features.drop('target', axis=1)
    y = features['target']

    scaler   = StandardScaler()
    X_scaled = scaler.fit_transform(X)

    model = XGBClassifier(
        n_estimators=200, learning_rate=0.03, max_depth=4,
        subsample=0.8, colsample_bytree=0.8, min_child_weight=3,
        gamma=0.1, reg_alpha=0.1, reg_lambda=1.0,
        eval_metric='logloss', random_state=42
    )

    cv_scores = cross_val_score(model, X_scaled, y, cv=5, scoring='accuracy')
    logger.info(f"[XGB] CV Accuracy: {cv_scores.mean():.3f} ± {cv_scores.std():.3f}")

    model.fit(X_scaled, y)
    joblib.dump(model, MODEL_PATH)
    joblib.dump(scaler, SCALER_PATH)
    logger.info(f"[XGB] Model saved.")
    return model


def predict_signal(df):
    if not os.path.exists(MODEL_PATH):
        logger.info("[XGB] No model found — training now...")
        train_model(df)

    if not os.path.exists(MODEL_PATH):
        return 0.5

    try:
        model  = joblib.load(MODEL_PATH)
        scaler = joblib.load(SCALER_PATH) if os.path.exists(SCALER_PATH) else None
        latest = extract_features(df).tail(1).drop('target', axis=1)
        if latest.empty:
            return 0.5
        X = scaler.transform(latest) if scaler else latest.values
        return model.predict_proba(X)[0][1]
    except Exception as e:
        logger.error(f"[XGB] Prediction error: {e}")
        return 0.5
