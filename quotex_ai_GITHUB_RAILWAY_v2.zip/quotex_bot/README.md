# Quotex AI Ultra Signal Bot 🤖📊

Automated forex signal bot for Quotex OTC trading.
Sends verified BUY/SELL signals directly to Telegram.

## How it works
```
[6 Data APIs] → Price Consensus Check
      ↓
[10+ Technical Indicators] → Strategy Score
      ↓
[XGBoost AI — 25 features] → AI Confidence
      ↓
[✅ Signal] → Telegram
```

## Deploy on Railway

1. Push this repo to GitHub
2. Go to [railway.app](https://railway.app) → New Project → Deploy from GitHub repo
3. Add these environment variables in Railway dashboard:

| Variable | Description |
|---|---|
| `TELEGRAM_BOT_TOKEN` | From @BotFather |
| `CHAT_ID` | Your Telegram chat ID |
| `TWELVE_API_KEY` | From twelvedata.com |
| `ALPHA_VANTAGE_API_KEY` | From alphavantage.co |
| `FINNHUB_API_KEY` | From finnhub.io |
| `POLYGON_API_KEY` | From polygon.io |

4. Click **Deploy** — signals start flowing to Telegram ✅

## Run locally
```bash
pip install -r requirements.txt
python main.py
```
