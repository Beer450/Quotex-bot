"""
health_check.py — COMPREHENSIVE API HEALTH CHECKER
===================================================
Checks all configured APIs on startup.
"""

import requests
import logging
from config import (
    TWELVE_API_KEY, ALPHA_VANTAGE_API_KEY, FINNHUB_API_KEY,
    POLYGON_API_KEY, TELEGRAM_BOT_TOKEN, CHAT_ID
)

logger = logging.getLogger(__name__)

def _check(name, url, success_fn):
    try:
        r = requests.get(url, timeout=8).json()
        if success_fn(r):
            logger.info(f"  ✅ {name}: Connected")
            return True
        else:
            logger.warning(f"  ⚠  {name}: Responded but check failed → {str(r)[:120]}")
            return False
    except Exception as e:
        logger.error(f"  ❌ {name}: {e}")
        return False

def check_twelvedata():
    return _check(
        "TwelveData",
        f"https://api.twelvedata.com/api_usage?apikey={TWELVE_API_KEY}",
        lambda r: 'timestamp' in r
    )

def check_alphavantage():
    return _check(
        "AlphaVantage",
        f"https://www.alphavantage.co/query?function=CURRENCY_EXCHANGE_RATE&from_currency=EUR&to_currency=USD&apikey={ALPHA_VANTAGE_API_KEY}",
        lambda r: 'Realtime Currency Exchange Rate' in r or 'Note' in r or 'Information' in r
    )

def check_finnhub():
    return _check(
        "Finnhub",
        f"https://finnhub.io/api/v1/forex/rates?base=EUR&token={FINNHUB_API_KEY}",
        lambda r: 'quote' in r or 'error' not in str(r).lower()
    )

def check_polygon():
    return _check(
        "Polygon.io",
        f"https://api.polygon.io/v2/aggs/ticker/C:EURUSD/range/1/minute/2024-01-01/2024-01-02?limit=1&apiKey={POLYGON_API_KEY}",
        lambda r: r.get('status') in ('OK', 'DELAYED') or r.get('resultsCount', -1) >= 0
    )

def check_exchangerate():
    return _check(
        "ExchangeRate-API",
        "https://open.er-api.com/v6/latest/EUR",
        lambda r: r.get('result') == 'success'
    )

def check_telegram():
    return _check(
        "Telegram Bot",
        f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/getMe",
        lambda r: r.get('ok')
    )

def run_full_health_check():
    logger.info("━━━ SYSTEM HEALTH CHECK ━━━")

    results = {
        "TwelveData":       check_twelvedata(),
        "AlphaVantage":     check_alphavantage(),
        "Finnhub":          check_finnhub(),
        "Polygon":          check_polygon(),
        "ExchangeRate-API": check_exchangerate(),
        "Telegram":         check_telegram(),
    }

    ok = sum(results.values())
    total = len(results)
    logger.info(f"━━━ {ok}/{total} SYSTEMS OK ━━━")

    # Critical: TwelveData + Telegram must pass
    if results["TwelveData"] and results["Telegram"]:
        return True
    else:
        logger.error("Critical services (TwelveData, Telegram) failed!")
        return False
