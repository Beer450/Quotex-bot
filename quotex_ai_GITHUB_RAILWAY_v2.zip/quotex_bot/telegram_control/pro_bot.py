"""
pro_bot.py — TELEGRAM SIGNAL SENDER
"""

import asyncio
import logging
from datetime import datetime, timedelta
import pytz
from telegram import Bot
from config import TELEGRAM_BOT_TOKEN, CHAT_ID, OTC_PAIR, SIGNAL_EXPIRY_MINUTES

logger = logging.getLogger(__name__)
PKT = pytz.timezone("Asia/Karachi")

DIRECTION_EMOJI = {"UP": "🟢📈", "DOWN": "🔴📉"}


def _run(coro):
    try:
        loop = asyncio.get_event_loop()
        if loop.is_closed():
            raise RuntimeError
        return loop.run_until_complete(coro)
    except RuntimeError:
        return asyncio.run(coro)


def send_signal(signal, price, score,
                strategy_score=None, ai_score=None,
                consensus_conf=None, ohlcv_sources=None):
    try:
        bot    = Bot(token=TELEGRAM_BOT_TOKEN)
        now    = datetime.now(PKT)
        expiry = now + timedelta(minutes=SIGNAL_EXPIRY_MINUTES)
        emoji  = DIRECTION_EMOJI.get(signal, "⚪")
        bar    = "█" * int(score // 10) + "░" * (10 - int(score // 10))
        srcs   = ", ".join(ohlcv_sources) if ohlcv_sources else "N/A"
        cons   = f"{consensus_conf:.0f}%" if consensus_conf is not None else "N/A"

        msg = (
            f"━━━━━━━━━━━━━━━━━━━━━━\n"
            f"{emoji}  *TRADE SIGNAL — OTC*\n"
            f"━━━━━━━━━━━━━━━━━━━━━━\n\n"
            f"📊 *Pair:* `{OTC_PAIR}`\n"
            f"💰 *Price:* `{price:.5f}`\n"
            f"⏰ *Time \\(PKT\\):* `{now.strftime('%H:%M')}` → `{expiry.strftime('%H:%M')}`\n"
            f"📉 *Direction:* *{signal}*\n"
            f"⏱ *Expiry:* {SIGNAL_EXPIRY_MINUTES} min\n\n"
            f"⚡ *Confidence:* `{score}%`\n"
            f"`{bar}`\n\n"
            f"🔬 *Tech Score:* `{strategy_score}%`\n"
            f"🤖 *AI Score:* `{ai_score}%`\n"
            f"🌐 *Consensus:* `{cons}`\n"
            f"📡 *Sources:* `{srcs}`\n\n"
            f"⚠️ _Trade Smart \\| Risk Management Required_\n"
            f"━━━━━━━━━━━━━━━━━━━━━━"
        )

        _run(bot.send_message(chat_id=CHAT_ID, text=msg, parse_mode='MarkdownV2'))
        logger.info(f"[Telegram] ✅ Signal sent: {signal} @ {price:.5f}")
    except Exception as e:
        logger.error(f"[Telegram] Failed: {e}")


def send_alert(text):
    try:
        bot = Bot(token=TELEGRAM_BOT_TOKEN)
        _run(bot.send_message(chat_id=CHAT_ID, text=text))
    except Exception as e:
        logger.error(f"[Telegram] Alert failed: {e}")
