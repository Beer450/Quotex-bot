"""
master_ai.py — MASTER ENGINE WITH CRASH RECOVERY + DETAILED LOGGING
"""

import time
import logging
from datetime import datetime, timezone

from data_feeds.multi_feed import get_combined_data
from strategies.rsi_ema_macd_fusion import get_signal
from ai_models.xgboost_validator import predict_signal, train_model
from telegram_control.pro_bot import send_signal, send_alert
from utils.health_check import run_full_health_check
from config import (
    AI_CONFIDENCE_THRESHOLD, STRATEGY_SCORE_THRESHOLD,
    CONSENSUS_MIN_SOURCES, SYMBOL
)

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(message)s'
)
logger = logging.getLogger(__name__)

CANDLE_COUNT    = 0
SIGNAL_COUNT    = 0
RETRAIN_INTERVAL = 300


def run_engine():
    global CANDLE_COUNT, SIGNAL_COUNT

    logger.info("=" * 50)
    logger.info("🚀 Quotex AI Ultra — Starting Engine")
    logger.info("=" * 50)

    if not run_full_health_check():
        logger.error("❌ Health check failed. Check API keys.")
        return

    send_alert("🟢 Bot started and running! Watching market every 60 seconds.")

    consecutive_errors = 0

    while True:
        try:
            CANDLE_COUNT += 1
            now_utc = datetime.now(timezone.utc)
            logger.info(f"── Candle #{CANDLE_COUNT} | {now_utc.strftime('%H:%M:%S UTC')} ──")

            # ── 1. Fetch Data ─────────────────────────────────────────────
            df = get_combined_data(SYMBOL)

            if df is None or len(df) < 55:
                logger.warning(f"⚠ Not enough data (got {len(df) if df is not None else 0} rows). Retrying in 30s...")
                time.sleep(30)
                continue

            consecutive_errors = 0
            ohlcv_sources  = getattr(df, 'ohlcv_sources',        [])
            consensus_conf = getattr(df, 'consensus_confidence',  0)
            last_close     = df['close'].iloc[-1]

            logger.info(f"📊 Price: {last_close:.5f} | Sources: {ohlcv_sources} | Consensus: {consensus_conf:.0f}%")

            # ── 2. Consensus Gate ─────────────────────────────────────────
            if consensus_conf < (CONSENSUS_MIN_SOURCES / 4 * 100):
                logger.warning(f"⚠ Consensus too low ({consensus_conf:.0f}%). Skipping.")
                time.sleep(60)
                continue

            # ── 3. Technical Strategy ─────────────────────────────────────
            strategy_signal, strategy_score = get_signal(df)
            logger.info(f"📈 Strategy: {strategy_signal or 'NO SIGNAL'} | Score: {strategy_score}")

            if not strategy_signal or strategy_score < STRATEGY_SCORE_THRESHOLD:
                logger.info(f"— Filtered by strategy (score={strategy_score} < {STRATEGY_SCORE_THRESHOLD})")
                time.sleep(60)
                continue

            # ── 4. AI Validation ──────────────────────────────────────────
            prob_up = predict_signal(df)
            ai_score_raw = prob_up if strategy_signal == "UP" else (1 - prob_up)
            logger.info(f"🤖 AI prob_up={prob_up:.3f} | Effective AI score: {ai_score_raw:.3f} | Threshold: {AI_CONFIDENCE_THRESHOLD}")

            is_valid = False
            if strategy_signal == "UP"   and prob_up >= AI_CONFIDENCE_THRESHOLD:
                is_valid = True
            elif strategy_signal == "DOWN" and prob_up <= (1 - AI_CONFIDENCE_THRESHOLD):
                is_valid = True

            if is_valid:
                SIGNAL_COUNT += 1
                confidence = round((strategy_score + ai_score_raw * 100) / 2, 1)

                logger.info(f"✅ SIGNAL #{SIGNAL_COUNT}: {strategy_signal} @ {last_close:.5f} | Confidence: {confidence}%")

                send_signal(
                    signal         = strategy_signal,
                    price          = last_close,
                    score          = confidence,
                    strategy_score = strategy_score,
                    ai_score       = round(ai_score_raw * 100, 1),
                    consensus_conf = consensus_conf,
                    ohlcv_sources  = ohlcv_sources
                )
            else:
                logger.info(f"🔴 AI rejected '{strategy_signal}' (prob_up={prob_up:.3f})")

            # ── 5. Auto-retrain ───────────────────────────────────────────
            if CANDLE_COUNT % RETRAIN_INTERVAL == 0:
                logger.info(f"🔄 Auto-retraining model at candle #{CANDLE_COUNT}...")
                train_model(df)

            time.sleep(60)

        except KeyboardInterrupt:
            logger.info("👋 Stopped by user.")
            send_alert("🔴 Bot stopped manually.")
            break

        except Exception as e:
            consecutive_errors += 1
            logger.error(f"💥 Error #{consecutive_errors}: {e}", exc_info=True)

            if consecutive_errors >= 5:
                send_alert(f"⚠️ Bot hit {consecutive_errors} errors in a row: {str(e)[:100]}")
                consecutive_errors = 0

            wait = min(30 * consecutive_errors, 300)
            logger.info(f"Retrying in {wait}s...")
            time.sleep(wait)
