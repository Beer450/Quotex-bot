"""
rsi_ema_macd_fusion.py — TUNED FOR MORE FREQUENT SIGNALS
Relaxed scoring so valid setups aren't over-filtered.
"""

import ta
import pandas as pd
import numpy as np
from datetime import datetime, timezone
from config import TRADE_SESSION_START_UTC, TRADE_SESSION_END_UTC


def _in_trading_session():
    hour = datetime.now(timezone.utc).hour
    return TRADE_SESSION_START_UTC <= hour <= TRADE_SESSION_END_UTC


def _candle_pattern_score(df):
    if len(df) < 3:
        return 0
    o = df['open'].values
    h = df['high'].values
    l = df['low'].values
    c = df['close'].values
    body      = c - o
    upper_wick = h - np.maximum(o, c)
    lower_wick = np.minimum(o, c) - l
    body_size  = np.abs(body)
    full_range = h - l + 1e-10

    # Hammer
    if lower_wick[-1] > 2 * body_size[-1] and upper_wick[-1] < body_size[-1]:
        return 15
    # Shooting Star
    if upper_wick[-1] > 2 * body_size[-1] and lower_wick[-1] < body_size[-1]:
        return -15
    # Bullish Engulfing
    if body[-1] > 0 and body[-2] < 0 and abs(body[-1]) > abs(body[-2]):
        return 20
    # Bearish Engulfing
    if body[-1] < 0 and body[-2] > 0 and abs(body[-1]) > abs(body[-2]):
        return -20
    return 0


def get_signal(df):
    if len(df) < 35:
        return None, 0

    if not _in_trading_session():
        return None, 0

    if 'datetime' in df.columns:
        df = df.sort_values('datetime').reset_index(drop=True)

    close = df['close'].astype(float)
    high  = df['high'].astype(float)
    low   = df['low'].astype(float)

    # ── Indicators ────────────────────────────────────────────────────────
    ema9  = ta.trend.EMAIndicator(close, 9).ema_indicator()
    ema21 = ta.trend.EMAIndicator(close, 21).ema_indicator()
    ema50 = ta.trend.EMAIndicator(close, 50).ema_indicator()

    macd_obj  = ta.trend.MACD(close)
    macd_line = macd_obj.macd().iloc[-1]
    macd_sig  = macd_obj.macd_signal().iloc[-1]
    macd_hist = macd_obj.macd_diff().iloc[-1]
    prev_hist = macd_obj.macd_diff().iloc[-2]

    adx_obj  = ta.trend.ADXIndicator(high, low, close, 14)
    adx      = adx_obj.adx().iloc[-1]
    di_plus  = adx_obj.adx_pos().iloc[-1]
    di_minus = adx_obj.adx_neg().iloc[-1]

    rsi = ta.momentum.RSIIndicator(close, 14).rsi().iloc[-1]

    stoch    = ta.momentum.StochasticOscillator(high, low, close, 14, 3)
    stoch_k  = stoch.stoch().iloc[-1]
    stoch_d  = stoch.stoch_signal().iloc[-1]

    bb    = ta.volatility.BollingerBands(close, 20, 2)
    bb_h  = bb.bollinger_hband().iloc[-1]
    bb_l  = bb.bollinger_lband().iloc[-1]
    bb_m  = bb.bollinger_mavg().iloc[-1]

    atr   = ta.volatility.AverageTrueRange(high, low, close, 14).average_true_range().iloc[-1]
    cci   = ta.trend.CCIIndicator(high, low, close, 20).cci().iloc[-1]
    willr = ta.momentum.WilliamsRIndicator(high, low, close, 14).williams_r().iloc[-1]

    last  = close.iloc[-1]
    l_e9  = ema9.iloc[-1]
    l_e21 = ema21.iloc[-1]
    l_e50 = ema50.iloc[-1]

    # Volatility filter — skip completely flat markets only
    if atr < (close.mean() * 0.00003):
        return None, 0

    # ── Scoring ──────────────────────────────────────────────────────────
    up_score = down_score = 0

    # EMA Stack (25 pts)
    if l_e9 > l_e21 > l_e50:
        up_score += 25
    elif l_e9 < l_e21 < l_e50:
        down_score += 25
    elif l_e9 > l_e21:
        up_score += 12
    elif l_e9 < l_e21:
        down_score += 12

    # Price vs EMA9 (10 pts)
    if last > l_e9:
        up_score += 10
    else:
        down_score += 10

    # MACD (15 pts)
    if macd_line > macd_sig:
        up_score   += 15 if macd_hist > prev_hist else 8
    else:
        down_score += 15 if macd_hist < prev_hist else 8

    # RSI (15 pts)
    if rsi < 35:
        up_score += 15
    elif rsi < 45:
        up_score += 8
    elif rsi > 65:
        down_score += 15
    elif rsi > 55:
        down_score += 8

    # Stochastic (10 pts)
    if stoch_k < 25 and stoch_k > stoch_d:
        up_score += 10
    elif stoch_k > 75 and stoch_k < stoch_d:
        down_score += 10
    elif stoch_k < 50:
        up_score += 4
    else:
        down_score += 4

    # Bollinger Bands (10 pts)
    if last <= bb_l:
        up_score += 10
    elif last >= bb_h:
        down_score += 10
    elif last > bb_m:
        up_score += 4
    else:
        down_score += 4

    # CCI (8 pts)
    if cci < -80:
        up_score += 8
    elif cci > 80:
        down_score += 8

    # Williams %R (7 pts)
    if willr < -75:
        up_score += 7
    elif willr > -25:
        down_score += 7

    # ADX (10 pts bonus)
    if adx > 20:
        if di_plus > di_minus:
            up_score += 10
        else:
            down_score += 10

    # Candle pattern
    pat = _candle_pattern_score(df)
    if pat > 0:
        up_score += pat
    elif pat < 0:
        down_score += abs(pat)

    # ── Decision ─────────────────────────────────────────────────────────
    total = up_score + down_score
    if total == 0:
        return None, 0

    if up_score > down_score:
        pct = int(up_score / total * 100)
        return ("UP", pct) if pct >= 55 else (None, 0)   # relaxed from 65
    else:
        pct = int(down_score / total * 100)
        return ("DOWN", pct) if pct >= 55 else (None, 0)
