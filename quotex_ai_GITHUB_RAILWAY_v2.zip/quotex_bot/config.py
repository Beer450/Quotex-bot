# ============================================================
# Quotex AI Ultra System — RAILWAY CONFIG
# ============================================================

import os

# --- Telegram Bot Settings ---
TELEGRAM_BOT_TOKEN = os.environ.get('TELEGRAM_BOT_TOKEN', '8615866639:AAFHKe5KMabwSxC3ZvQ82Mcy_u8mJxzWJ7o')
CHAT_ID            = os.environ.get('CHAT_ID', '8016036711')

# --- Market Data Settings ---
SYMBOL    = 'EUR/USD'
OTC_PAIR  = 'AUD/NZD OTC'
TIMEFRAME = '1min'

# ============================================================
# DATA API KEYS
# ============================================================
TWELVE_API_KEY        = os.environ.get('TWELVE_API_KEY',         'e7102efec090439599e615b12f8e1fd8')
ALPHA_VANTAGE_API_KEY = os.environ.get('ALPHA_VANTAGE_API_KEY',  '8HZOYQSSNFJVHDN3')
FINNHUB_API_KEY       = os.environ.get('FINNHUB_API_KEY',        'd6ide9hr01ql9cifu02gd6ide9hr01ql9cifu030')
POLYGON_API_KEY       = os.environ.get('POLYGON_API_KEY',        'xegb8Mf3mlZvnwgAXZ0CbbLL9_eyTYZS')
FIXER_API_KEY         = os.environ.get('FIXER_API_KEY',          'demo')
EXCHANGERATE_API_KEY  = os.environ.get('EXCHANGERATE_API_KEY',   'demo')

# ============================================================
# AI / SIGNAL ENGINE SETTINGS — TUNED FOR MORE SIGNALS
# ============================================================
AI_CONFIDENCE_THRESHOLD  = 0.60   # Lowered from 0.65
STRATEGY_SCORE_THRESHOLD = 58     # Lowered from 65
CONSENSUS_MIN_SOURCES    = 1      # Lowered from 2 — only need 1 source to agree
PRICE_TOLERANCE_PCT      = 0.003  # Slightly more tolerant

SIGNAL_EXPIRY_MINUTES = 1

# Trade session hours (UTC) — WIDENED to cover more hours
# PKT = UTC+5, so this covers 5 AM – 3 AM PKT (almost 24/7)
TRADE_SESSION_START_UTC = 0    # Midnight UTC
TRADE_SESSION_END_UTC   = 23   # 11 PM UTC

# Model save path
MODEL_PATH = 'ai_models/trained_xgb_model.pkl'
