"""
multi_feed.py — ENHANCED MULTI-SOURCE DATA AGGREGATOR
======================================================
Sources:
  1. TwelveData      (primary, paid)
  2. Alpha Vantage   (secondary, free)
  3. Yahoo Finance   (tertiary, free)
  4. Finnhub         (real-time quote verification)
  5. Polygon.io      (backup OHLCV)
  6. Fixer.io        (live spot rate cross-check)
  7. ExchangeRate-API (free live spot rate)

Logic:
  - Fetch OHLCV history from as many sources as available
  - Cross-check the LATEST CLOSE price across all live-quote sources
  - Accept price if ≥ CONSENSUS_MIN_SOURCES agree within PRICE_TOLERANCE_PCT
  - Return the most trusted OHLCV DataFrame + a consensus confidence score
"""

import requests
import pandas as pd
import yfinance as yf
import logging
from datetime import datetime, timezone

from config import (
    TWELVE_API_KEY, ALPHA_VANTAGE_API_KEY, FINNHUB_API_KEY,
    POLYGON_API_KEY, FIXER_API_KEY, EXCHANGERATE_API_KEY,
    SYMBOL, TIMEFRAME,
    CONSENSUS_MIN_SOURCES, PRICE_TOLERANCE_PCT
)

logger = logging.getLogger(__name__)

# ── Helpers ─────────────────────────────────────────────────────────────────

def _to_float(df, cols):
    for c in cols:
        if c in df.columns:
            df[c] = pd.to_numeric(df[c], errors='coerce')
    return df

def _symbol_base_quote(symbol):
    """'EUR/USD' → ('EUR', 'USD')"""
    return symbol.replace("-", "/").upper().split("/")


# ── OHLCV Sources ────────────────────────────────────────────────────────────

def get_twelvedata(symbol=SYMBOL, timeframe=TIMEFRAME, outputsize=150):
    """TwelveData — primary OHLCV source."""
    try:
        url = (f"https://api.twelvedata.com/time_series"
               f"?symbol={symbol}&interval={timeframe}"
               f"&apikey={TWELVE_API_KEY}&outputsize={outputsize}")
        r = requests.get(url, timeout=10).json()
        if 'values' in r:
            df = pd.DataFrame(r['values'])
            df = _to_float(df, ['open', 'high', 'low', 'close', 'volume'])
            df['datetime'] = pd.to_datetime(df['datetime'])
            df = df.sort_values('datetime').reset_index(drop=True)
            logger.info(f"[TwelveData] {len(df)} candles loaded.")
            return df
        else:
            logger.warning(f"[TwelveData] Error: {r.get('message', r)}")
    except Exception as e:
        logger.error(f"[TwelveData] Exception: {e}")
    return None


def get_alphavantage(symbol=SYMBOL, timeframe='1min'):
    """Alpha Vantage — secondary OHLCV source (free, 5 req/min limit)."""
    try:
        av_symbol = symbol.replace("/", "")  # EURUSD
        url = (f"https://www.alphavantage.co/query"
               f"?function=FX_INTRADAY&from_symbol={av_symbol[:3]}"
               f"&to_symbol={av_symbol[3:]}&interval={timeframe}"
               f"&outputsize=compact&apikey={ALPHA_VANTAGE_API_KEY}")
        r = requests.get(url, timeout=10).json()
        key = f"Time Series FX ({timeframe})"
        if key in r:
            df = pd.DataFrame(r[key]).T
            df.index.name = 'datetime'
            df = df.reset_index()
            df.columns = [c.split('. ')[-1] for c in df.columns]
            df = df.rename(columns={'1. open': 'open', '2. high': 'high',
                                     '3. low': 'low', '4. close': 'close'})
            # Handle both old and new Alpha Vantage column names
            col_map = {'open': 'open', 'high': 'high', 'low': 'low', 'close': 'close'}
            df.columns = [col_map.get(c, c) for c in df.columns]
            df = _to_float(df, ['open', 'high', 'low', 'close'])
            df['datetime'] = pd.to_datetime(df['datetime'])
            df = df.sort_values('datetime').tail(150).reset_index(drop=True)
            logger.info(f"[AlphaVantage] {len(df)} candles loaded.")
            return df
        else:
            logger.warning(f"[AlphaVantage] Error: {r}")
    except Exception as e:
        logger.error(f"[AlphaVantage] Exception: {e}")
    return None


def get_yfinance(symbol=SYMBOL):
    """Yahoo Finance — free OHLCV fallback."""
    try:
        yf_symbol = symbol.replace("/", "") + "=X"
        ticker = yf.Ticker(yf_symbol)
        df = ticker.history(period="1d", interval="1m").tail(150)
        if not df.empty:
            df = df.reset_index()
            df.columns = [c.lower() for c in df.columns]
            df = df.rename(columns={'date': 'datetime', 'datetime': 'datetime'})
            if 'datetime' not in df.columns and 'timestamp' in df.columns:
                df = df.rename(columns={'timestamp': 'datetime'})
            df = df[['datetime', 'open', 'high', 'low', 'close']].copy()
            df = _to_float(df, ['open', 'high', 'low', 'close'])
            df = df.sort_values('datetime').reset_index(drop=True)
            logger.info(f"[YFinance] {len(df)} candles loaded.")
            return df
    except Exception as e:
        logger.error(f"[YFinance] Exception: {e}")
    return None


def get_polygon(symbol=SYMBOL, timeframe='1'):
    """Polygon.io — backup OHLCV (free tier: 15-min delay but still useful)."""
    try:
        base, quote = _symbol_base_quote(symbol)
        from_dt = pd.Timestamp.utcnow() - pd.Timedelta(hours=4)
        from_str = from_dt.strftime('%Y-%m-%d')
        to_str   = pd.Timestamp.utcnow().strftime('%Y-%m-%d')
        url = (f"https://api.polygon.io/v2/aggs/ticker/C:{base}{quote}"
               f"/range/{timeframe}/minute/{from_str}/{to_str}"
               f"?adjusted=true&sort=asc&limit=150&apiKey={POLYGON_API_KEY}")
        r = requests.get(url, timeout=10).json()
        if r.get('resultsCount', 0) > 0:
            df = pd.DataFrame(r['results'])
            df['datetime'] = pd.to_datetime(df['t'], unit='ms', utc=True).dt.tz_convert(None)
            df = df.rename(columns={'o': 'open', 'h': 'high', 'l': 'low', 'c': 'close', 'v': 'volume'})
            df = _to_float(df, ['open', 'high', 'low', 'close'])
            df = df[['datetime', 'open', 'high', 'low', 'close']].sort_values('datetime').reset_index(drop=True)
            logger.info(f"[Polygon] {len(df)} candles loaded.")
            return df
        else:
            logger.warning(f"[Polygon] No data: {r.get('status', r)}")
    except Exception as e:
        logger.error(f"[Polygon] Exception: {e}")
    return None


# ── Live Spot Price Sources (for consensus check) ────────────────────────────

def get_live_price_finnhub(symbol=SYMBOL):
    """Finnhub real-time forex quote."""
    try:
        base, quote = _symbol_base_quote(symbol)
        url = (f"https://finnhub.io/api/v1/forex/rates"
               f"?base={base}&token={FINNHUB_API_KEY}")
        r = requests.get(url, timeout=8).json()
        price = r.get('quote', {}).get(quote)
        if price:
            logger.info(f"[Finnhub] Live price: {price}")
            return float(price)
    except Exception as e:
        logger.error(f"[Finnhub] Exception: {e}")
    return None


def get_live_price_fixer(symbol=SYMBOL):
    """Fixer.io live spot rate."""
    try:
        base, quote = _symbol_base_quote(symbol)
        url = (f"http://data.fixer.io/api/latest"
               f"?access_key={FIXER_API_KEY}&symbols={quote}&base={base}")
        r = requests.get(url, timeout=8).json()
        if r.get('success'):
            price = r['rates'].get(quote)
            if price:
                logger.info(f"[Fixer] Live price: {price}")
                return float(price)
    except Exception as e:
        logger.error(f"[Fixer] Exception: {e}")
    return None


def get_live_price_exchangerate(symbol=SYMBOL):
    """ExchangeRate-API — free live spot rate (no key needed for basic)."""
    try:
        base, quote = _symbol_base_quote(symbol)
        url = f"https://open.er-api.com/v6/latest/{base}"
        r = requests.get(url, timeout=8).json()
        if r.get('result') == 'success':
            price = r['rates'].get(quote)
            if price:
                logger.info(f"[ExchangeRate-API] Live price: {price}")
                return float(price)
    except Exception as e:
        logger.error(f"[ExchangeRate-API] Exception: {e}")
    return None


def get_live_price_yfinance(symbol=SYMBOL):
    """Yahoo Finance live bid price."""
    try:
        yf_symbol = symbol.replace("/", "") + "=X"
        info = yf.Ticker(yf_symbol).fast_info
        price = getattr(info, 'last_price', None)
        if price:
            logger.info(f"[YFinance-Live] Live price: {price}")
            return float(price)
    except Exception as e:
        logger.error(f"[YFinance-Live] Exception: {e}")
    return None


# ── Consensus Engine ─────────────────────────────────────────────────────────

def build_price_consensus(symbol=SYMBOL):
    """
    Collect live prices from multiple free APIs and compute consensus.
    Returns: (consensus_price, confidence_pct, sources_agreed, total_sources)
    """
    live_sources = {
        "YFinance":       get_live_price_yfinance(symbol),
        "ExchangeRateAPI": get_live_price_exchangerate(symbol),
        "Finnhub":        get_live_price_finnhub(symbol),
        "Fixer":          get_live_price_fixer(symbol),
    }

    prices = {k: v for k, v in live_sources.items() if v is not None}
    if not prices:
        logger.warning("[Consensus] No live prices available.")
        return None, 0.0, 0, 0

    values = list(prices.values())
    median_price = sorted(values)[len(values) // 2]

    agreed = {
        k: v for k, v in prices.items()
        if abs(v - median_price) / median_price <= PRICE_TOLERANCE_PCT
    }

    confidence = len(agreed) / len(live_sources) * 100
    consensus_price = sum(agreed.values()) / len(agreed) if agreed else median_price

    logger.info(f"[Consensus] Price={consensus_price:.5f} | "
                f"Sources agreed: {len(agreed)}/{len(live_sources)} | "
                f"Confidence: {confidence:.0f}%")
    return consensus_price, confidence, len(agreed), len(live_sources)


# ── Main Entry Point ─────────────────────────────────────────────────────────

def get_combined_data(symbol=SYMBOL):
    """
    Fetch OHLCV from multiple sources, verify live price consensus,
    and return the best DataFrame with an attached consensus_confidence attribute.
    """
    # 1. Fetch OHLCV from all sources
    sources = {
        "TwelveData":  get_twelvedata(symbol),
        "AlphaVantage": get_alphavantage(symbol),
        "YFinance":    get_yfinance(symbol),
        "Polygon":     get_polygon(symbol),
    }
    available = {k: v for k, v in sources.items() if v is not None and not v.empty}

    if not available:
        logger.error("[MultiFeed] ALL data sources failed!")
        return None

    # 2. Priority order: TwelveData > AlphaVantage > YFinance > Polygon
    priority = ["TwelveData", "AlphaVantage", "YFinance", "Polygon"]
    best_df = None
    best_source = None
    for src in priority:
        if src in available:
            best_df = available[src]
            best_source = src
            break

    # 3. Build live price consensus
    consensus_price, consensus_conf, agreed, total = build_price_consensus(symbol)

    # 4. Patch the last candle's close with consensus price if we have it
    if consensus_price and agreed >= CONSENSUS_MIN_SOURCES:
        last_close = best_df['close'].iloc[-1]
        drift = abs(last_close - consensus_price) / last_close
        if drift < PRICE_TOLERANCE_PCT * 5:  # within 1% → safe to patch
            best_df = best_df.copy()
            best_df.loc[best_df.index[-1], 'close'] = consensus_price
            logger.info(f"[MultiFeed] Last close patched from {last_close:.5f} → {consensus_price:.5f}")
        else:
            logger.warning(f"[MultiFeed] Large drift {drift:.4%} between {best_source} and consensus — skipping patch")

    # 5. Cross-validate last close across OHLCV sources
    ohlcv_closes = [df['close'].iloc[-1] for df in available.values()]
    if len(ohlcv_closes) >= 2:
        ref = ohlcv_closes[0]
        mismatches = sum(1 for p in ohlcv_closes if abs(p - ref) / ref > PRICE_TOLERANCE_PCT)
        if mismatches:
            logger.warning(f"[MultiFeed] {mismatches}/{len(ohlcv_closes)} OHLCV sources disagree on last close")

    logger.info(f"[MultiFeed] Using '{best_source}' | {len(best_df)} rows | "
                f"OHLCV sources: {list(available.keys())} | "
                f"Consensus conf: {consensus_conf:.0f}%")

    best_df.consensus_confidence = consensus_conf
    best_df.ohlcv_sources = list(available.keys())
    return best_df
