import logging
from core_engine.master_ai import run_engine

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(message)s'
)

if __name__ == '__main__':
    run_engine()
